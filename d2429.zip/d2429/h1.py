import base64

# File paths for uploaded images
file_paths = [
    "img/img1.jpg",
    "img/img2.jpg",
    "img/img3.jpg"
]

# Convert images to Base64 strings
base64_strings = {}
for path in file_paths:
    with open(path, "rb") as img_file:
        encoded = base64.b64encode(img_file.read()).decode("utf-8")
        base64_strings[path.split("/")[-1]] = encoded

# Show only a small preview (first 120 characters) to avoid huge output
{fname: b64[:120] + "..." for fname, b64 in base64_strings.items()}
